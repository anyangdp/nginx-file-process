

#ifndef NGX_HAVE_UNISTD_H
#define NGX_HAVE_UNISTD_H  1
#endif


#ifndef NGX_HAVE_INTTYPES_H
#define NGX_HAVE_INTTYPES_H  1
#endif


#ifndef NGX_HAVE_LIMITS_H
#define NGX_HAVE_LIMITS_H  1
#endif


#ifndef NGX_HAVE_SYS_FILIO_H
#define NGX_HAVE_SYS_FILIO_H  1
#endif


#ifndef NGX_HAVE_SYS_PARAM_H
#define NGX_HAVE_SYS_PARAM_H  1
#endif


#ifndef NGX_HAVE_SYS_MOUNT_H
#define NGX_HAVE_SYS_MOUNT_H  1
#endif


#ifndef NGX_HAVE_SYS_STATVFS_H
#define NGX_HAVE_SYS_STATVFS_H  1
#endif


#ifndef NGX_DARWIN
#define NGX_DARWIN  1
#endif

